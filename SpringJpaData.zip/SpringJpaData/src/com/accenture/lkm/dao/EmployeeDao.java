package com.accenture.lkm.dao;

import java.io.Serializable;

import org.springframework.data.repository.CrudRepository;

import com.accenture.lkm.entity.EmployeeEntity;

public interface EmployeeDao extends CrudRepository<EmployeeEntity, Integer>{

		
}
