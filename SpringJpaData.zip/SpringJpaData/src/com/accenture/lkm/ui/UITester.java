package com.accenture.lkm.ui;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.accenture.lkm.dao.EmployeeDao;
import com.accenture.lkm.dao.EmployeeDaoImpl;
import com.accenture.lkm.entity.EmployeeEntity;

public class UITester {
	

	
	public static void main(String args[])
	{
		EmployeeDao employeeDao=null;

		try {
			ApplicationContext context=new ClassPathXmlApplicationContext("com/accenture/lkm/resources/SpringJpa.xml");
			employeeDao=(EmployeeDao)context.getBean("employeeDao"); 
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		//addEmployee(employeeDao);
		//updateEmployee(employeeDao);
		deleteEmployee(employeeDao);
	}
	
	public static void addEmployee(EmployeeDao employeeDao)
	{	
		EmployeeEntity bean=new EmployeeEntity();
		bean.setInsertTime(new Date());
		bean.setName("Aakash");
		bean.setRole("CEO");
		bean.setSalary(1000000000.00);
		
		try {
			EmployeeEntity result=employeeDao.save(bean);
			int id=result.getEmployeeId();
			
			System.out.println("id: "+id);
			System.out.println("Employee registered successfully");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void updateEmployee(EmployeeDao employeeDao)
	{
		EmployeeEntity bean=new EmployeeEntity();
		bean=employeeDao.findOne(1003);
		
		bean.setName("huzzi");
		
		try {
		EmployeeEntity result=employeeDao.save(bean);
		int id=result.getEmployeeId();
		System.out.println("id: "+id);
		System.out.println("Employee updated successfully");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
				
	}
	public static void deleteEmployee(EmployeeDao employeeDao)
	{
	
		employeeDao.delete(1003);
		System.out.println("Employee updated successfully");	
				
	}



}