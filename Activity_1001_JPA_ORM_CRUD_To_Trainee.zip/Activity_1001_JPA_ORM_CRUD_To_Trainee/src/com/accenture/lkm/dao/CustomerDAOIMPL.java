package com.accenture.lkm.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.accenture.lkm.businessbean.CustomerBean;
import com.accenture.lkm.entity.CustomerEntity;




@Repository
@SuppressWarnings("unchecked")
public class CustomerDAOIMPL implements CustomerDAO {

	@Autowired
	private EntityManagerFactory entityManagerFactory;
	
	public Integer addCustomer(CustomerBean customer) throws Exception {
		// TODO Auto-generated method stub
		Integer customerID = 0;
		EntityManager entityManager = null;
		
		CustomerEntity customerEntityBean=convertBeantoEntity(customer);
		try {
			entityManager=entityManagerFactory.createEntityManager();
			entityManager.getTransaction().begin();
			entityManager.persist(customerEntityBean);
			entityManager.getTransaction().commit();
			
		
		} catch (Exception exception) {

			throw exception;
		} finally {
			if (entityManager != null) {
				entityManager.close();
			}
		}

		return customerID;
	}

	public CustomerBean findCustomerById(Integer customerId) throws Exception {
		
		
		CustomerBean customer = null;
		EntityManager entityManager = null;
		
		try {
			//9EntityManagerFactory entityManagerFactory = JPAUtility.getEntityManagerFactory();
			entityManager = entityManagerFactory.createEntityManager();
			
			CustomerEntity customerEntity = (CustomerEntity) entityManager.find(CustomerEntity.class, customerId);

			if (customerEntity != null) {
				customer=convertEntityToBean(customerEntity);
			}

		} catch (Exception exception) {

			throw exception;
		} finally {
			if (entityManager != null) {
				entityManager.close();
			}
		}

		return customer;
	}
//
	public CustomerBean updateCustomerBillById(CustomerBean customerBean) throws Exception {
		CustomerBean customerRet = null;
		EntityManager entityManager = null;
		try {
			//EntityManagerFactory entityManagerFactory = JPAUtility.getEntityManagerFactory();
			entityManager = entityManagerFactory.createEntityManager();

			CustomerEntity customerEntity = (CustomerEntity) entityManager.find(CustomerEntity.class, customerBean.getCustomerId());

			if (customerEntity != null) {
				
				entityManager.getTransaction().begin();
					customerEntity.setBill(customerBean.getBill());
					customerRet = convertEntityToBean(customerEntity);
				entityManager.getTransaction().commit();
				
			}

		} catch (Exception exception) {

			throw exception;
		} finally {
			if (entityManager != null) {
				entityManager.close();
			}
		}

		return customerRet;
	}

	public CustomerBean deleteCustomerById(Integer customerId) throws Exception {
		CustomerBean customerRet = null;
		EntityManager entityManager = null;
		try {

			entityManager =entityManagerFactory.createEntityManager();
			CustomerEntity customerEntity = (CustomerEntity) entityManager.find(CustomerEntity.class, customerId);
			if( customerEntity!= null)
			
			{	entityManager.getTransaction().begin();
					entityManager.remove(customerEntity);
				entityManager.getTransaction().commit();;
				customerRet =convertEntityToBean(customerEntity);
			}			

			
		} catch (Exception exception) {

			throw exception;
		} finally {
			if (entityManager != null) {
				entityManager.close();
			}
		}

		return customerRet;
	}

	@Override
	public List<CustomerBean> getCustomersWithinDateRange(Date lowerBound,Date upperBound) throws Exception{
		List<CustomerBean> listCustomer = null;
		EntityManager entityManager = null;
		try {
			
			entityManager =entityManagerFactory.createEntityManager();
			listCustomer=new ArrayList<CustomerBean>();
//			List<CustomerEntity> listCustomerEntity= (List<CustomerEntity>) entityManager.createQuery("select e.customerName from Customer e where e.purchaseDate BETWEEN :a AND :b");
			Query q=entityManager.createQuery("select e.customerName from Customer e where e.purchaseDate BETWEEN :a AND :b");
			q.setParameter("a", lowerBound);
			q.setParameter("b", upperBound);
			List<CustomerEntity> listCustomerEntity=q.getResultList();

			for (CustomerEntity entity:listCustomerEntity){
				CustomerBean cust= convertEntityToBean(entity);
				listCustomer.add(cust);
			}
			
		} catch (Exception exception) {

			throw exception;
		} finally {
			if (entityManager != null) {
				entityManager.close();
			}
		}

		return listCustomer;
	}

	@Override
	public Integer updateCustomerBillByName(String name,Double bill) throws Exception{
		Integer ret = null;
		EntityManager entityManager = null;
		try {

			// Your Code goes here
		
		} catch (Exception exception) {

			throw exception;
		} finally {
			if (entityManager != null) {
				entityManager.close();
			}
		}

		return ret;
	}
	public static CustomerEntity convertBeantoEntity(CustomerBean bean)
	{
		CustomerEntity custentity=new CustomerEntity();
		BeanUtils.copyProperties(bean, custentity);
		return custentity;
	}
	public static CustomerBean convertEntityToBean(CustomerEntity entity)
	{
		CustomerBean bean=new CustomerBean();
		BeanUtils.copyProperties(entity,bean);
		return bean;
	}

	

}
