package com.accenture.lkm.db.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;

@Configuration
@PropertySource("classpath:com/accenture/lkm/resources/cst_conn.properties")
public class SpringDBConfig {

	@Value("${cst_db_driver}")
	private String DriverName;
	
	@Value("${cst_db_url}")
	private String url;
	
	@Value("${cst_user}")
	private String user;
	
	@Value("${cst_password}")
	private String password;
	
	@Bean
	public static PropertySourcesPlaceholderConfigurer propertyConfigInDev()
	{
		return new PropertySourcesPlaceholderConfigurer();
	}
	
	@Bean(name="cst_Datasource")
	public DriverManagerDataSource getDataSource()
	{
		DriverManagerDataSource datasource=new DriverManagerDataSource();
		datasource.setDriverClassName(DriverName);
		datasource.setUrl(url);
		datasource.setUsername(user);
		datasource.setPassword(password);
		return datasource;
	}
	
	public HibernateJpaVendorAdapter getVendorAdapter()
	{
		HibernateJpaVendorAdapter adapter=new HibernateJpaVendorAdapter();
		adapter.setShowSql(true);
		adapter.setGenerateDdl(false);
		adapter.setDatabasePlatform("org.hibernate.dialect.MySQLDialect");
		return adapter;
	}
	
	@Bean(name="cst_entityManagerFactory")
	public LocalContainerEntityManagerFactoryBean geEntityManagerFactory(DriverManagerDataSource datasource)
	{
		LocalContainerEntityManagerFactoryBean factoryBuilder=new LocalContainerEntityManagerFactoryBean();
		factoryBuilder.setDataSource(datasource);
		factoryBuilder.setJpaVendorAdapter(getVendorAdapter());
		factoryBuilder.setPackagesToScan("com.accenture.lkm.entity");
		
		
		return factoryBuilder;
		
	}
	
	
	
	
	
	
	
}
