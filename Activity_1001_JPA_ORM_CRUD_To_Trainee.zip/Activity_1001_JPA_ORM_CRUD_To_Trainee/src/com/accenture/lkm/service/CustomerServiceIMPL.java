package com.accenture.lkm.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.accenture.lkm.businessbean.CustomerBean;
import com.accenture.lkm.dao.CustomerDAO;


@Service
public class CustomerServiceIMPL implements CustomerService{

	
		@Autowired
		private CustomerDAO customerDAO;
		public Integer addCustomer(CustomerBean customer) throws Exception {

			int custID = 0;
			try {
				customerDAO.addCustomer(customer);

			} catch (Exception exception) {
				throw exception;
			}

			return custID;

		}
		public CustomerBean findCustomerById(Integer customerId) throws Exception {
			CustomerBean customerBeanRet =null;
			try {
				
				System.out.println("HEllo service");
				customerBeanRet = customerDAO.findCustomerById(customerId);
				
				if(customerBeanRet==null){
					throw new Exception("Given CustomerId is invalid, please try with a valid CustomerId");
				}
			} catch (Exception exception) {
				throw exception;
			}
			return customerBeanRet;
		}


		@Override
		public CustomerBean updateCustomerBillById(CustomerBean customerBean)throws Exception{
			CustomerBean customerBeanRet =null;
			try {
					
				
				customerBeanRet = customerDAO.updateCustomerBillById(customerBean);
				if(customerBeanRet==null){
					throw new Exception("Given CustomerId is invalid, please try with a valid CustomerId");
				}
			} catch (Exception exception) {
				throw exception;
			}
			return customerBeanRet;
		}


		@Override
		public CustomerBean deleteCustomerById(Integer customerId) throws Exception {
			CustomerBean customerBeanRet =null;
			try {
				
				 customerBeanRet= customerDAO.deleteCustomerById(customerId);
				
				if(customerBeanRet==null){
					throw new Exception("Given CustomerId is invalid, please try with a valid CustomerId");
				}
			} catch (Exception exception) {
				throw exception;
			}
			return customerBeanRet;
		}
		public List<CustomerBean> getCustomersWithinDateRange(Date lowerBound,Date upperBound) throws Exception{
			List<CustomerBean> list=null;
			try {
				list=customerDAO.getCustomersWithinDateRange(lowerBound, upperBound);
				
			} catch (Exception exception) {
				throw exception;
			}
			return list;
		}
		
		
		
		public Integer updateCustomerBillByName(String name, Double bill)throws Exception{
			Integer ret=null;
			try {
				
			
				
				// your code goes here
				
			} catch (Exception exception) {
				throw exception;
			}
			return ret;
		}


}
