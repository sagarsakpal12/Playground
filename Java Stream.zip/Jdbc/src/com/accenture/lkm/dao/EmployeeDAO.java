package com.accenture.lkm.dao;

import java.sql.*;

import com.accenture.lkm.businessbean.EmployeeBean;
public interface EmployeeDAO {

	public int insertEmployee(EmployeeBean bean) throws ClassNotFoundException,SQLException;
	public int readEmployee() throws ClassNotFoundException,SQLException;
	public int updateEmployee(EmployeeBean bean) throws ClassNotFoundException,SQLException;
	public int deleteEmployee(EmployeeBean bean) throws ClassNotFoundException,SQLException;
}
