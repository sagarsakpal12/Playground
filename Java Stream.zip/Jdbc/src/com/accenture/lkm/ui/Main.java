package com.accenture.lkm.ui;

import java.sql.SQLException;
import java.sql.Date;

import com.accenture.lkm.businessbean.EmployeeBean;
import com.accenture.lkm.service.EmployeeService;
import com.accenture.lkm.service.EmployeeServiceImpl;

public class Main {
	
	
	static void insertEmployee() throws ClassNotFoundException,SQLException
	{
		EmployeeService e=new  EmployeeServiceImpl();
		EmployeeBean eb=new EmployeeBean();
		eb.setEmployeeId(1006);
		eb.setEmployeeName("Huzaifa");
		eb.setRole("ADA");
		eb.setSalary(5000.0);		
		long millis=System.currentTimeMillis();    
		eb.setInsertTime(new Date(millis));
		e.insertEmployee(eb);
	}
	static void readEmployee() throws ClassNotFoundException,SQLException
	{
		EmployeeService e=new  EmployeeServiceImpl();
		e.readEmployee();
	}	
	static void updateEmployee() throws ClassNotFoundException,SQLException
	{
		EmployeeService e=new  EmployeeServiceImpl();
		EmployeeBean eb=new EmployeeBean();
		eb.setSalary(500000.0);
		eb.setEmployeeName("Sagar");
		
		e.updateEmployee(eb);
		
	}	
	static void deleteEmployee() throws ClassNotFoundException,SQLException
	{
		EmployeeService e=new  EmployeeServiceImpl();
		EmployeeBean eb=new EmployeeBean();
		eb.setEmployeeName("Huzaifa");
		e.deleteEmployee(eb);
		
	}	
	public static void main(String args[]) throws ClassNotFoundException,SQLException
	{
		
		//readEmployee();
		//updateEmployee();
		insertEmployee();
		//deleteEmployee();	
		
	}
}
