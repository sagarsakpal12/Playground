package com.accenture.lkm.utility;
import java.sql.*;
public class DBUtility {

	public static String url="jdbc:mysql://localhost:3306/jdbcdemos";
	public static String username="root";
	public static String password="root";
	private static Connection  connection=null;
	 
	public static Connection getDBConnection() throws ClassNotFoundException,SQLException
	{
		
		//Class.forName("com.mysql.jdbc.Driver");
		System.out.println("Driver registered!!");
		
		connection=DriverManager.getConnection(url,username,password);
		System.out.println("Connection established!");
		
		DatabaseMetaData meta=connection.getMetaData();
		System.out.println("JDBC Version:"+meta.getJDBCMajorVersion());
		System.out.println("Product:"+meta.getDatabaseProductName());
		return connection;
	}
	public static void getDestroyConnection() throws SQLException
	{
		connection.close();
	}
	
}
