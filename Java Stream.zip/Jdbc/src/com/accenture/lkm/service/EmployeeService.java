package com.accenture.lkm.service;

import java.sql.SQLException;

import com.accenture.lkm.businessbean.EmployeeBean;

public interface EmployeeService {

	public int insertEmployee(EmployeeBean bean) throws ClassNotFoundException,SQLException;
	public int readEmployee() throws ClassNotFoundException,SQLException;
	public int updateEmployee(EmployeeBean bean) throws ClassNotFoundException,SQLException;
	public int deleteEmployee(EmployeeBean bean) throws ClassNotFoundException,SQLException;
}
