package com.accenture.lkm.service;

import java.sql.SQLException;

import com.accenture.lkm.businessbean.EmployeeBean;
import com.accenture.lkm.dao.EmployeeDAO;
import com.accenture.lkm.dao.EmployeeDAOImpl;

public class EmployeeServiceImpl  implements EmployeeService{

	EmployeeDAO employeeDAO=new EmployeeDAOImpl();
	@Override
	public int insertEmployee(EmployeeBean bean) throws ClassNotFoundException, SQLException {
		
		employeeDAO.insertEmployee(bean);
		return 0;
	}

	@Override
	public int readEmployee() throws ClassNotFoundException, SQLException {
		try {
			employeeDAO.readEmployee();	
		}
		catch(ClassNotFoundException | SQLException e) {
			System.out.println(e.getMessage());
		}
		catch(Exception e) {
			throw e;
		}
		return 0;
	}

	@Override
	public int updateEmployee(EmployeeBean bean) throws ClassNotFoundException, SQLException {
		employeeDAO.updateEmployee(bean);
		return 0;
	}

	@Override
	public int deleteEmployee(EmployeeBean bean) throws ClassNotFoundException, SQLException {
		employeeDAO.deleteEmployee(bean);
		return 0;
	}

}
