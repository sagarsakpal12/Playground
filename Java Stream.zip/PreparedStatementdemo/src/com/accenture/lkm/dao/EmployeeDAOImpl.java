package com.accenture.lkm.dao;

import com.accenture.lkm.businessbean.EmployeeBean;
import com.accenture.lkm.utility.DBUtility;

import java.sql.*;
public class EmployeeDAOImpl implements EmployeeDAO{
	private static Connection connection=null;
	private static PreparedStatement statement=null;
	private static Statement st=null;
	@Override
	public int insertEmployee(EmployeeBean bean) throws ClassNotFoundException, SQLException {
		connection=DBUtility.getDBConnection();
		int rowsUpdate=0;
		
		int id=bean.getEmployeeId();
		String ename=bean.getEmployeeName();
		String role=bean.getRole();
		Date insertTime=new java.sql.Date(bean.getInsertTime().getTime());
		
		System.out.println(bean.getInsertTime());
		System.out.println(insertTime);
		double salary=bean.getSalary();
			
		String insertData="insert into employee values(?,?,?,?,?)";
		statement=connection.prepareStatement(insertData);
		statement.setInt(1,id);
		statement.setString(2,ename);
		statement.setString(3,role);
		statement.setDate(4,insertTime);
		statement.setDouble(5,salary);
			
		rowsUpdate=statement.executeUpdate();
		if(rowsUpdate>0)
		{
			System.out.println(rowsUpdate+" rows updated");
		}
		else		{
			System.out.println("Some error occured");
		}
		return 0;
	}
	@Override
	public int readEmployee() throws SQLException {
		
			try {
				String retrievedata = "select * from employee";
				connection = DBUtility.getDBConnection();
				st = connection.createStatement();
				ResultSet resultSet = st.executeQuery(retrievedata);
				
				System.out.println("Retrieveing Query executed!!");
				while (resultSet.next()) {
					System.out.println("Employee ID: " + resultSet.getInt("employeeId") 
							+ "\nEmployee name: "+ resultSet.getString("employeeName") 
							+ "\nRole: " + resultSet.getString("role")
							+ "\nInsert Time: " + resultSet.getString("insertTime") 
							+ "\nSalary: "+ resultSet.getDouble("salary"));
					System.out.println("===========================================");
				}				
			} 
			catch(Exception e)
			{
				System.out.println(e);
			}
			finally
				{
					connection.close();
				}
			return 0;
		}
		
	@Override
	public int updateEmployee(EmployeeBean bean) throws ClassNotFoundException, SQLException {
		connection=DBUtility.getDBConnection();
		
		int rowsUpdate=0;
		
		//String role=bean.getRole();
		double salary=bean.getSalary();
		String name=bean.getEmployeeName();
		 String updateData = "Update employee "+ "set salary = ? "+ "where employeeName = ?";
		//String updateData="Update employee set salary=? where employeeName=?";
		PreparedStatement ps = connection.prepareStatement(updateData);
		ps.setDouble(1, salary);
		ps.setString(2,name);
		
		//Statement st=connection.createStatement();
		rowsUpdate = ps.executeUpdate();
		if(rowsUpdate>0)
		{
			System.out.println(rowsUpdate+" rows updated");
		}
		else		{
			System.out.println("Some error occured");
		}
		return 0;
	}
	@Override
	public int deleteEmployee(EmployeeBean bean) throws ClassNotFoundException, SQLException {
		connection=DBUtility.getDBConnection();
			int rowsUpdate=0;
		
		
		String name=bean.getEmployeeName();
		 String updateData = "delete from employee where employeeName = ?";
		//String updateData="Update employee set salary=? where employeeName=?";
		PreparedStatement ps = connection.prepareStatement(updateData);
		ps.setString(1, name);
		
		//Statement st=connection.createStatement();
		rowsUpdate = ps.executeUpdate();
		if(rowsUpdate>0)
		{
			System.out.println(rowsUpdate+" rows deleted");
		}
		else		{
			System.out.println("Some error occured");
		}
		return 0;
	}
	
	

}
