package com.accenture.lkm.ui;

import java.sql.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.accenture.lkm.entity.EmployeeEntity;

public class JpaMain {

	public static void main(String args[])
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPADemo");
		EntityManager em=emf.createEntityManager();
		EmployeeEntity e=new EmployeeEntity();
		e.setEmployeeId(100);
		e.setEmployeeName("Sagar");
		e.setRole("ADA");
		e.setSalary(10000.0);
		long m=System.currentTimeMillis();
		e.setInsertTime(new Date(m));
		
		EntityTransaction transaction=em.getTransaction();
		transaction.begin();
		em.persist(e);
		transaction.commit();
		System.out.println("Record savaed"+e.getEmployeeId());
		em.close();
		emf.close();
		
		
		
 
	}
}
