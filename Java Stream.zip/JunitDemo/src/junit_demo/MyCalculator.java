package junit_demo;

public class MyCalculator {
	public int getSum(int a, int b) {

		return a + b;
	}

	public int getDifference(int a, int b) {
		return a - b;
	}

	public double getProduct(double a, double b) {
		return a * b;
	}

	public int getQuotient(int a, int b)
	{
		System.out.println("Inside getQuotient");
	
		return a / b;
	}

	public int getStringLength(String sinput) {
		return sinput.length();
	}	
}
