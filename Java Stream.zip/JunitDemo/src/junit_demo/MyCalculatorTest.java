package junit_demo;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


public class MyCalculatorTest{
	
	private MyCalculator c1;	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("Inside setUpBeforeClass");
		
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("Inside tearDownAfterClass");
	}

	@Before
	public void setUp() throws Exception {
		
		System.out.println("Inside setUp");
		c1=new MyCalculator();
	}

	@After
	public void tearDown() throws Exception {
		
		System.out.println("Inside tearDown");
		c1=null;
	}

	@Test
	public void testGetQuotient() {
		System.out.println("Inside Test1");
		
		try {
			assertEquals(5,c1.getQuotient(20,4));
			//fail("Not yet implemented");
			}
			catch(ArithmeticException e)
			{
				assertTrue(false);
			}
					
	}
	@Test     //(expected=ArithmeticException.class)
	public void testGetQuotientDivideByZero()
	{
		System.out.println("Inside Test1");
		try {
		assertEquals(5,c1.getQuotient(20,0));
		
		}
		catch(ArithmeticException e)
		{
			//fail("Not yet implemented");
		}
		
		
	}
	
}
