package com.accenture.lkm.config;

public interface IEmployee {

	IAddress getAddress();

	int getId();

	String getName();

}