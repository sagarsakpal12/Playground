package com.accenture.lkm.config;

public interface IAddress {

	String getAddressLine1();

	String getAddressLine2();

}