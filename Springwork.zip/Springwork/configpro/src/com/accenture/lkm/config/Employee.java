package com.accenture.lkm.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;

public class Employee implements IEmployee {
	
	//@Value("1001")
	private int id;
	//
	//@Value("Huzzi")
	private String name;
	
	//@Autowired
	//@Qualifier("addr")
	private IAddress address;
	
	
	public Employee()
	{	
		System.out.println("Employee()");
	}
	public Employee(IAddress address)
	{
		super();
		this.address=address;
		System.out.println("Employee cons 1");
	}
	
	public Employee(int id, String name, IAddress address) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		//System.out.println("Employee Para constructor");
		System.out.println("id: "+id+" Name: "+name+" address: "+address.getAddressLine1()+" address: "+address.getAddressLine2());
		
	}
	@Override
	public IAddress getAddress() {
		return address;
	}
	public void setAddress(IAddress address) {
		this.address = address;
		System.out.println("setAddress in Employee()");
	}
	
	@Override
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
		System.out.println("Employee setId()");
	}
	@Override
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
		System.out.println("Employee setName()");
	}
	public String toString()
	{
		return "\nid: "+id+" \nName: "+name+" \naddress1: "+address.getAddressLine1()+" \naddress2: "+address.getAddressLine2();
	}
	
}
