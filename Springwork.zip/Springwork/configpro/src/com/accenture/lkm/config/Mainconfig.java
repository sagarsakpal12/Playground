package com.accenture.lkm.config;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.accenture.com.resources2.MyConfig;

public class Mainconfig {
	public static void main(String args[])
	{
		ApplicationContext context=new AnnotationConfigApplicationContext(MyConfig.class);
//		IAddress a=(IAddress) context.getBean("addBean");
//		System.out.println(a.getAddressLine1());
//		System.out.println(a.getAddressLine2());
//		
		IEmployee e=(IEmployee) context.getBean("empBean2");
//		System.out.println(e.getId());
//		System.out.println(e.getName());
//		System.out.println(e.getAddress().getAddressLine1());
//		System.out.println(e.getAddress().getAddressLine2());
		System.out.println(e);
		
	}
}
