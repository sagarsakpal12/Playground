package com.accenture.com.resources2;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.accenture.lkm.config.Address;
import com.accenture.lkm.config.Employee;

@Configuration
@ComponentScan(basePackages = {"com.accenture.lkm.config"})
public class MyConfig {
		
		@Bean(name = "addBean")
		public Address getAddress()
		{
			Address address=new Address();
			address.setAddressLine1("Ladakh");
			address.setAddressLine2("Bali");
			return address;
		}	
		
		@Bean(name = "addBean2")
		public Address getAddressbean()
		{
			Address address=new Address();
			address.setAddressLine1("Ladakgjh");
			address.setAddressLine2("Bali");
			return address;
		}	
		@Bean(name="empBean")
		public Employee getEmployee()
		{
			Employee e=new Employee();
			e.setId(1001);
			e.setName("huzzi");
			e.setAddress(getAddress());
			return e;
		}
		@Bean(name="empBean2")
		public Employee getEmployeeBean(Address addBean2)
		{
			Employee e=new Employee();
			e.setId(2001);
			e.setName("Hello");
			e.setAddress(addBean2);
			return e;
		}
}
