import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.accenture.lkm.cons.IAddress;
import com.accenture.lkm.cons.IEmployee;

public class ContructorMain {
	public static void main(String args[])
	{
		ApplicationContext context=null;
		context=new ClassPathXmlApplicationContext("resources1/context1.xml");
		
		
		System.out.println("------------------------------------------------------");
		IEmployee e=(IEmployee)context.getBean("emp");
		System.out.println(e.getId());
		System.out.println(e.getName());
		
		
		
		
	}
}
