import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.accenture.lkm.cons.IEmployee;

public class AutowireNameMain {

	public static void main(String args[])
	{
		ApplicationContext context=null;
		context=new ClassPathXmlApplicationContext("resources1/AutowireNameContext1.xml");
		
		System.out.println("------------------------------");
		IEmployee e=(IEmployee) context.getBean("emp");
		System.out.println(e);	
	}
}
