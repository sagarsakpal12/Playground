package com.accenture.lkm.cons;

public interface IEmployee {

	IAddress getAddress();

	int getId();

	String getName();

}