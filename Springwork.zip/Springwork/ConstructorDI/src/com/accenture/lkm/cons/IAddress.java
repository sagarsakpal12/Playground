package com.accenture.lkm.cons;

public interface IAddress {

	String getAddressLine1();

	String getAddressLine2();

}