import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.accenture.lkm.cons.IEmployee;

public class AutoMain {
	
		public static void main(String args[])
		{
			ApplicationContext context=null;
			context=new ClassPathXmlApplicationContext("resources1/Autowire.xml");
					
			IEmployee e=(IEmployee)context.getBean("emp");
			
			ConfigurableApplicationContext context2 = (ConfigurableApplicationContext) context;
			context2.close();
		}
}
