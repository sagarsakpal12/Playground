package com.accenture.lkm;

public interface IAddress {

	String getAddressLine1();

	String getAddressLine2();

}