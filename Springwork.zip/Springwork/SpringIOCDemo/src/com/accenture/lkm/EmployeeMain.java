package com.accenture.lkm;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmployeeMain {
		public static void main(String args[])
		{
			
			ApplicationContext context=null;
			context=new ClassPathXmlApplicationContext("resources/context.xml");
			
			IEmployee e=(IEmployee)context.getBean("e");
//			System.out.println(e.getId());
//			System.out.println(e.getName());
//			System.out.println(e.getAddress().getAddressLine1());;
//			System.out.println("------------------------");
//			IEmployee e2=(IEmployee)context.getBean("e");
//			IAddress addresse2=e2.getAddress();
//			System.out.println(addresse2.getAddressLine1());
			System.out.println("------------------------");
			//System.out.println(e2);
//			IAddress address=context.getBean(IAddress.class);
//			System.out.println(address.getAddressLine1());
//			System.out.println(address.getAddressLine2());
					
			System.out.println("----------p------------");
//			IAddress a2=context.getBean("a2",IAddress.class);
//			System.out.println(a2.getAddressLine1());
//			System.out.println(a2.getAddressLine2());
			
			System.out.println("----------p emp------------");
//			IEmployee e3=(IEmployee)context.getBean("e2");
//			System.out.println(e3.getId());
//			System.out.println(e3.getName());
//			System.out.println(e3.getAddress().getAddressLine1());
//			System.out.println(e3.getAddress().getAddressLine2());
//			
			ConfigurableApplicationContext context2=(ConfigurableApplicationContext) context;
			context2.close();
//			
	}
}
