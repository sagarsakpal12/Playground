package com.accenture.lkm;

public class Employee implements IEmployee {
	private int id;
	private String name;
	private IAddress address;
	
	@Override
	public IAddress getAddress() {
		return address;
	}
	public void setAddress(IAddress address) {
		this.address = address;
	}
	public Employee()
	{	
		System.out.println("Employee()");
	}
	@Override
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
		System.out.println("Employee setId()");
	}
	@Override
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
		System.out.println("Employee setName()");
	}
	
}
