package com.accenture.lkm;

public interface IEmployee {

	IAddress getAddress();

	int getId();

	String getName();

}